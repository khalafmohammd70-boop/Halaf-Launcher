# Halaf Launcher — starter project

This is the first Android Studio source-project foundation for Halaf Launcher.

## Included in v0.1.0
- Android TV / TV Box launcher entry point (HOME intent).
- Horizontal rows of installed launchable apps.
- Dark glass-style app tiles and remote-focus highlight.
- Blue, purple and red accent theme selection (in-memory prototype).
- Official generated Halaf H logo installed as Android launcher icon.
- Arabic, Turkish, English and French language selector (initial UI prototype).
- Western digits in the displayed clock/date pattern.

## Open and build
1. Install Android Studio with Android SDK Platform 35 and JDK 17.
2. Open this folder in Android Studio.
3. Let Gradle sync.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The generated APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## Important
This is a starter build, not the complete feature set discussed. The first milestone establishes the launcher shell and app browsing. Persistent preferences, full localization resources/RTL polish, font import, wallpaper picker/blur, movable/resizable widgets, prayer-time and live sports data providers, app management, backup/restore, and device testing remain to be implemented. The source has not been compiled or device-tested in this environment. The launcher icon is included in all standard Android density folders.
