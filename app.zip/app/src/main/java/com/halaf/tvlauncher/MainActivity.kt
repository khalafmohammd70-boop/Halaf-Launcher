package com.halaf.tvlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("halaf_home", MODE_PRIVATE) }
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var dashboard: LinearLayout
    private lateinit var infoRow: LinearLayout
    private lateinit var scoreBar: LinearLayout
    private lateinit var dock: LinearLayout
    private val accent = Color.rgb(255, 65, 150)
    private val white = Color.WHITE
    private val appPackages = mutableListOf<String>()

    private val clockTick = object : Runnable {
        override fun run() {
            if (::clock.isInitialized) {
                clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
                date.text = SimpleDateFormat("EEEE، d MMMM yyyy", Locale("ar")).format(Date())
            }
            handler.postDelayed(this, 30_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        loadSavedApps()
        buildScreen()
        handler.post(clockTick)
    }

    override fun onDestroy() {
        handler.removeCallbacks(clockTick)
        super.onDestroy()
    }

    private fun buildScreen() {
        val root = FrameLayout(this)
        val wallpaper = ImageView(this).apply {
            setImageResource(R.drawable.halaf_wallpaper)
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        root.addView(wallpaper, FrameLayout.LayoutParams(-1, -1))
        root.addView(View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0x44000A1B, 0x55000000, 0x99000000.toInt()))
        }, FrameLayout.LayoutParams(-1, -1))

        dashboard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(28), dp(18), dp(28), dp(14))
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        root.addView(dashboard, FrameLayout.LayoutParams(-1, -1))
        buildHeader()
        buildInfoCards()
        buildScores()
        buildDock()
        setContentView(root)
        dock.getChildAt(0)?.requestFocus()
    }

    private fun buildHeader() {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        clock = text("--:--", 36f, white, true)
        date = text("", 14f, white, false)
        left.addView(clock); left.addView(date)
        row.addView(left, LinearLayout.LayoutParams(0, dp(82), 1f))
        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL or Gravity.END }
        right.addView(text("مساء الخير، أهلاً بك", 23f, white, true).apply { gravity = Gravity.END })
        right.addView(text("HALAF TV  •  الشاشة الرئيسية", 13f, 0xFFE8DDE8.toInt(), false).apply { gravity = Gravity.END })
        row.addView(right, LinearLayout.LayoutParams(0, dp(82), 1f))
        val customize = pillButton("⚙  تخصيص الشاشة") { showCustomizeDialog() }
        row.addView(customize, LinearLayout.LayoutParams(dp(164), dp(46)))
        dashboard.addView(row)
    }

    private fun buildInfoCards() {
        infoRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val prayer = glassCard("مواقيت الصلاة", "الفجر     6:26", "قيم تجريبية • تحتاج ربط مصدر مواقيت")
        val weather = glassCard("الطقس", "20°   ☁", "عرض تجريبي • يحتاج مصدر طقس")
        infoRow.addView(prayer, LinearLayout.LayoutParams(0, dp(112), 1f).apply { marginEnd = dp(10) })
        infoRow.addView(weather, LinearLayout.LayoutParams(0, dp(112), 1f))
        dashboard.addView(infoRow, LinearLayout.LayoutParams(-1, dp(124)).apply { topMargin = dp(12) })
        applyVisibility()
    }

    private fun glassCard(title: String, main: String, sub: String): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(12))
            background = panelBackground()
        }
        card.addView(text(title, 17f, white, true))
        card.addView(text(main, 25f, white, true).apply { setPadding(0, dp(4), 0, dp(2)) })
        card.addView(text(sub, 12f, 0xFFE8DDE8.toInt(), false))
        return card
    }

    private fun buildScores() {
        scoreBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(10), dp(16), dp(10))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(0xE85B092D.toInt(), 0xD52A102D.toInt(), 0xE85B092D.toInt())).apply {
                cornerRadius = dp(20).toFloat(); setStroke(dp(2), accent)
            }
        }
        scoreBar.addView(text("⚽  نتائج المباريات", 16f, white, true), LinearLayout.LayoutParams(dp(170), -2))
        scoreBar.addView(scoreMatch("ريال مدريد", "2 - 1", "برشلونة", "انتهت"), LinearLayout.LayoutParams(0, dp(58), 1f))
        scoreBar.addView(View(this).apply { setBackgroundColor(0x66FFFFFF) }, LinearLayout.LayoutParams(dp(1), dp(38)))
        scoreBar.addView(scoreMatch("ليفربول", "3 - 0", "مانشستر سيتي", "انتهت"), LinearLayout.LayoutParams(0, dp(58), 1f))
        dashboard.addView(scoreBar, LinearLayout.LayoutParams(-1, dp(78)).apply { topMargin = dp(12) })
        applyVisibility()
    }

    private fun scoreMatch(home: String, score: String, away: String, state: String): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        box.addView(text(home, 14f, white, true))
        box.addView(text("  $score  ", 20f, white, true))
        box.addView(text(away, 14f, white, true))
        box.addView(text("  • $state", 11f, 0xFFFFC5D9.toInt(), false))
        return box
    }

    private fun buildDock() {
        dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        dashboard.addView(dock, LinearLayout.LayoutParams(-1, dp(92)).apply { topMargin = dp(14) })
        rebuildDock()
    }

    private fun rebuildDock() {
        if (!::dock.isInitialized) return
        dock.removeAllViews()
        val add = appTile("＋", "إضافة تطبيق") { showAppPicker() }
        dock.addView(add, LinearLayout.LayoutParams(dp(145), dp(76)).apply { marginEnd = dp(9) })
        val visible = appPackages.toList()
        visible.forEach { pkg ->
            val info = try { packageManager.getApplicationInfo(pkg, 0) } catch (_: Exception) { null }
            if (info != null) {
                val name = packageManager.getApplicationLabel(info).toString()
                val tile = appTile("", name) { launchPackage(pkg) }
                try {
                    val icon = packageManager.getApplicationIcon(info)
                    tile.findViewWithTag<ImageView>("app_icon")?.setImageDrawable(icon)
                } catch (_: Exception) { }
                tile.setOnLongClickListener { removeApp(pkg); true }
                dock.addView(tile, LinearLayout.LayoutParams(0, dp(76), 1f).apply { marginEnd = dp(9) })
            }
        }
        if (visible.isEmpty()) {
            dock.addView(appTile("▦", "التطبيقات") { showAppPicker() }, LinearLayout.LayoutParams(0, dp(76), 1f))
        }
    }

    private fun appTile(symbol: String, title: String, action: () -> Unit): LinearLayout {
        val tile = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = panelBackground()
            isFocusable = true
            isFocusableInTouchMode = true
            setOnClickListener { action() }
            setOnFocusChangeListener { v, focused ->
                v.background = panelBackground(if (focused) accent else 0x887D536D.toInt())
                v.scaleX = if (focused) 1.035f else 1f
                v.scaleY = if (focused) 1.035f else 1f
            }
        }
        if (symbol.isNotEmpty()) tile.addView(text(symbol, 27f, white, true))
        else tile.addView(ImageView(this).apply { tag = "app_icon"; layoutParams = LinearLayout.LayoutParams(dp(34), dp(34)) })
        tile.addView(text(title, 13f, white, true).apply { maxLines = 2; gravity = Gravity.CENTER; setPadding(dp(6), 0, dp(4), 0) })
        return tile
    }

    private fun showCustomizeDialog() {
        val labels = arrayOf("إظهار مواقيت الصلاة", "إظهار الطقس", "إظهار شريط نتائج المباريات")
        val keys = arrayOf("show_prayer", "show_weather", "show_scores")
        val checks = BooleanArray(3) { prefs.getBoolean(keys[it], true) }
        AlertDialog.Builder(this)
            .setTitle("تخصيص الشاشة الرئيسية")
            .setMultiChoiceItems(labels, checks) { _, which, checked -> checks[which] = checked }
            .setPositiveButton("حفظ") { _, _ ->
                keys.forEachIndexed { i, key -> prefs.edit().putBoolean(key, checks[i]).apply() }
                applyVisibility()
            }
            .setNeutralButton("إدارة التطبيقات") { _, _ -> showAppPicker() }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun applyVisibility() {
        if (!::infoRow.isInitialized || !::scoreBar.isInitialized) return
        // Cards are ordered RTL: prayer first, weather second.
        infoRow.getChildAt(0)?.visibility = if (prefs.getBoolean("show_prayer", true)) View.VISIBLE else View.GONE
        infoRow.getChildAt(1)?.visibility = if (prefs.getBoolean("show_weather", true)) View.VISIBLE else View.GONE
        scoreBar.visibility = if (prefs.getBoolean("show_scores", true)) View.VISIBLE else View.GONE
    }

    private fun showAppPicker() {
        val launchIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val installed = packageManager.queryIntentActivities(launchIntent, PackageManager.MATCH_ALL)
            .map { it.activityInfo.packageName to it.loadLabel(packageManager).toString() }
            .distinctBy { it.first }
            .filter { it.first != packageName }
            .sortedBy { it.second.lowercase() }
        if (installed.isEmpty()) {
            Toast.makeText(this, "لم يتم العثور على تطبيقات", Toast.LENGTH_SHORT).show(); return
        }
        val names = installed.map { (pkg, label) -> (if (appPackages.contains(pkg)) "✓  " else "＋  ") + label }.toTypedArray()
        val selected = BooleanArray(installed.size) { appPackages.contains(installed[it].first) }
        AlertDialog.Builder(this).setTitle("إضافة أو إزالة التطبيقات")
            .setMultiChoiceItems(names, selected) { _, which, checked ->
                val pkg = installed[which].first
                if (checked && !appPackages.contains(pkg)) appPackages.add(pkg)
                if (!checked) appPackages.remove(pkg)
            }
            .setPositiveButton("حفظ") { _, _ -> saveApps(); rebuildDock() }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun removeApp(pkg: String) {
        appPackages.remove(pkg); saveApps(); rebuildDock()
        Toast.makeText(this, "تمت الإزالة من الشاشة الرئيسية فقط", Toast.LENGTH_SHORT).show()
    }

    private fun launchPackage(pkg: String) {
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent != null) startActivity(intent) else Toast.makeText(this, "تعذر فتح التطبيق", Toast.LENGTH_SHORT).show()
    }

    private fun loadSavedApps() {
        appPackages.clear()
        appPackages.addAll(prefs.getStringSet("apps", emptySet()) ?: emptySet())
        if (appPackages.isEmpty()) {
            val launchIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            packageManager.queryIntentActivities(launchIntent, PackageManager.MATCH_ALL)
                .map { it.activityInfo.packageName }
                .distinct()
                .filter { it != packageName }
                .take(5)
                .forEach { appPackages.add(it) }
        }
    }

    private fun saveApps() { prefs.edit().putStringSet("apps", appPackages.toSet()).apply() }

    private fun pillButton(label: String, action: () -> Unit) = TextView(this).apply {
        text = label; textSize = 14f; setTextColor(white); gravity = Gravity.CENTER
        background = panelBackground(); isFocusable = true
        setOnClickListener { action() }
        setOnFocusChangeListener { v, focused -> v.background = panelBackground(if (focused) accent else 0x887D536D.toInt()) }
    }

    private fun panelBackground(stroke: Int = 0x887D536D.toInt()) = GradientDrawable().apply {
        setColor(0xB83E102F.toInt()); cornerRadius = dp(18).toFloat(); setStroke(dp(1), stroke)
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        gravity = Gravity.CENTER_VERTICAL
        setShadowLayer(3f, 1f, 2f, Color.BLACK)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
